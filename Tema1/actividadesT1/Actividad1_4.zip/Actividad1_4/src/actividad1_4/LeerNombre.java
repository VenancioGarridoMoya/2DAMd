package actividad1_4;
public class LeerNombre {
    public static void main(String[] args) {
        int salida=0;
        String mensaje = switch(args.length){
            case 0 ->{
                salida=-1;
                yield "Falta parámetro de entrada";
            }
            case 1 -> args[0];
            default ->{
                salida=-1;
                yield "Demasiados parámetros de entrada";
            }      
        };
        System.out.println(mensaje);
        System.exit(salida);
    }
}
