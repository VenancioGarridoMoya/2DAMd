package actividad1_4;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class Actividad1_4 {
    public static void main(String[] args) throws IOException {
        // creamos objeto File al directorio donde esta Ejemplo2
        File directorio = new File("./src/actividad1_4");
       
        //Valor de salida 0
        //ProcessBuilder pb = new ProcessBuilder("java", "LeerNombre.java", "parámetro1");

        //Valor de salida -1
        //ProcessBuilder pb = new ProcessBuilder("java", "LeerNombre.java");
        //Valor de salida -1
        ProcessBuilder pb = new ProcessBuilder("java", "LeerNombre.java","parámetro1","parámetro2");
        // se establece el directorio donde se encuentra el ejecutable
        pb.directory(directorio);

        // se ejecuta el proceso
        Process p = pb.start();

        // obtener la salida devuelta por el proceso
        try {
                InputStream is = p.getInputStream();
                int caracter;
                while ((caracter = is.read()) != -1)
                        System.out.print((char) caracter);
                is.close();
        } catch (IOException e) {
            System.out.println(e);
        }

        // COMPROBACIÓN DE ERROR - 0 bien - 1 mal
        int valorExit;
        try {
            valorExit = p.waitFor();
            System.out.println("Valor de Salida: " + valorExit);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }
}
